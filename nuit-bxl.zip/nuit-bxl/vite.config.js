import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Repo is "Nuit.bxl" -> served at /Nuit.bxl/ on GitHub Pages.
// If you deploy to a custom domain or Netlify/Vercel root, set base: "/".
export default defineConfig({
  plugins: [react()],
  base: "/Nuit.bxl/",
});
